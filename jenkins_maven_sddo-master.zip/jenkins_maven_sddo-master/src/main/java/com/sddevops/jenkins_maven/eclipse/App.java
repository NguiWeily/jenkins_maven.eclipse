package com.sddevops.jenkins_maven.eclipse;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	System.out.println("Nights!");
    }
}
